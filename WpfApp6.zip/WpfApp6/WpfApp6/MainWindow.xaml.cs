﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Newtonsoft.Json;
namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private string? lastUsedFilePath=null; 
        SolidColorBrush white = new SolidColorBrush(Colors.White);
        SolidColorBrush selectedBackgroundBrush = new SolidColorBrush(Colors.LightBlue);
        TextRange? previousSelection = null;

        private void savebtn_Click(object sender, RoutedEventArgs e)
        {
            lastUsedFilePath = jsonFilePathTextBox.Text + ".json";
            string jsonFilePath = jsonFilePathTextBox.Text + ".json";

            TextRange textRange = new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd);
            string textToSave = textRange.Text;

            string jsonContent = JsonConvert.SerializeObject(textToSave, Formatting.Indented);

            try
            {
                File.WriteAllText(jsonFilePath, jsonContent);
                MessageBox.Show("JSON file saved successfully.", "Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving JSON file: " + ex.Message, "Error");
            }
        }
        private void loadbtn_Click(object sender, RoutedEventArgs e)
        {
            string jsonFilePath = jsonFilePathTextBox.Text + ".json";

            try
            {
                string jsonContent = File.ReadAllText(jsonFilePath);

                string? textToLoad = JsonConvert.DeserializeObject<string>(jsonContent);

                richTextBox.Document.Blocks.Clear();
                richTextBox.Document.Blocks.Add(new Paragraph(new Run(textToLoad)));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading JSON file: " + ex.Message, "Error");
            }
        }
        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            previousSelection = new TextRange(richTextBox.Selection.Start, richTextBox.Selection.End);
            previousSelection.ApplyPropertyValue(TextElement.BackgroundProperty, white);
            richTextBox.SelectAll();
            previousSelection = new TextRange(richTextBox.Selection.Start, richTextBox.Selection.End);
            previousSelection.ApplyPropertyValue(TextElement.BackgroundProperty, selectedBackgroundBrush);
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            previousSelection = new TextRange(richTextBox.Selection.Start, richTextBox.Selection.End);
            previousSelection.ApplyPropertyValue(TextElement.BackgroundProperty, white);
            richTextBox.Copy();
            previousSelection = new TextRange(richTextBox.Selection.Start, richTextBox.Selection.End);
            previousSelection.ApplyPropertyValue(TextElement.BackgroundProperty, selectedBackgroundBrush);

        }

        private void Cut_Click(object sender, RoutedEventArgs e)
        {
            richTextBox.Cut();
        }

        private void Paste_Click(object sender, RoutedEventArgs e)
        {
            string clipboardText = Clipboard.GetText();
            TextPointer currentCaretPosition = richTextBox.CaretPosition;

            if (currentCaretPosition != null)
            {
                currentCaretPosition.InsertTextInRun(clipboardText);
                previousSelection = new TextRange(richTextBox.Selection.Start, richTextBox.Selection.End);
                previousSelection.ApplyPropertyValue(TextElement.BackgroundProperty, white);

                TextPointer newPosition = currentCaretPosition.GetPositionAtOffset(clipboardText.Length);
                if (newPosition != null)
                {
                    richTextBox.CaretPosition = newPosition;
                }
            }
        }

        private void autoSaveCheckbox_Checked(object sender, RoutedEventArgs e)
        {
            if (autoSaveCheckbox.IsChecked == true)
            {
                TextRange textRange = new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd);
                string textToSave = textRange.Text;

                if (!string.IsNullOrWhiteSpace(lastUsedFilePath))
                {
                    try
                    {
                        string jsonContent = JsonConvert.SerializeObject(textToSave, Formatting.Indented);
                        File.WriteAllText(lastUsedFilePath, jsonContent);

                        MessageBox.Show("AutoSave enabled. JSON file saved successfully.", "AutoSave");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("AutoSave error: " + ex.Message, "AutoSave Error");
                    }
                }
                else
                {
                    MessageBox.Show("No last used file path available. Please specify a file path first.", "AutoSave Error");
                }
            }
        }

    }

}
